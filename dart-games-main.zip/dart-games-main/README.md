Fix Mario 2
Fix Yoshis Island
Add btd 1-4
Add Duck life ones
